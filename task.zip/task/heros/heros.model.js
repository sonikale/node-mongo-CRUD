var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var herosSchema = new Schema({
    name :{
        type: String,
       
    },
    address : {
        type: String,
       
    },
    emailId:{
        type:String
    },
    phoneno:{
        type:Number
    },
    age:{
        type:Number
    }
}, {
    timestamps: true
});

module.exports = herosSchema;