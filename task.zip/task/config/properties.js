var mongoose = require('mongoose');
var chalk = require('chalk');
var dbURL = require('./properties').DB;



module.exports = {
    PORT : 4000,
    DB : 'mongodb://localhost:27017/crud-mean',
}